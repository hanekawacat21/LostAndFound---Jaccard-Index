DS 170: Symbolic-Lexical Campus Lost and Found Matcher -- starter test

This example verifies ONLY the existing models.py, loader.py and preprocessor.py.
It does not run forward chaining, constraint pruning, scoring, ranking or evaluation.

Open this folder in VS Code and run from its terminal:
    python test_modules.py
On some Windows systems:
    py test_modules.py

No external Python packages are needed.
