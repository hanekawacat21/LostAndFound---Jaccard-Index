"""Data ingestion utilities for the DS 170 Campus Lost and Found Matcher.

Place this file at src/loader.py alongside src/models.py.
"""

import csv
import json
import re
from datetime import date
from typing import Dict, List, Set, Tuple

from .models import Fact, Report, Rule


def load_reports(filepath: str) -> Tuple[List[Report], List[Report]]:
    """Load reports.csv and return (lost_reports, found_reports).

    Expected columns: id, domain, date, zone, text.
    Leading/trailing whitespace is trimmed; entirely blank rows are skipped.
    """
    lost_reports: List[Report] = []
    found_reports: List[Report] = []

    with open(filepath, "r", encoding="utf-8-sig", newline="") as file:
        reader = csv.DictReader(file)
        required = {"id", "domain", "date", "zone", "text"}
        if reader.fieldnames is None or not required.issubset(reader.fieldnames):
            raise ValueError(f"reports.csv must contain columns: {sorted(required)}")

        for line_number, row in enumerate(reader, start=2):
            if all(not str(value or "").strip() for value in row.values()):
                continue
            if any(not isinstance(row[field], str) for field in required):
                raise ValueError(f"Missing or malformed value on CSV line {line_number}")

            values = {field: row[field].strip() for field in required}
            try:
                report_date = date.fromisoformat(values["date"])
            except ValueError as exc:
                raise ValueError(
                    f"Invalid date on CSV line {line_number}: {values['date']!r}"
                ) from exc

            report = Report(
                id=values["id"],
                domain=values["domain"],
                date=report_date,
                zone=values["zone"],
                text=values["text"],
            )
            if report.id.startswith("L"):
                lost_reports.append(report)
            elif report.id.startswith("F"):
                found_reports.append(report)
            else:
                raise ValueError(
                    f"Unknown report ID on CSV line {line_number}: {report.id!r}; "
                    "expected prefix L or F"
                )

    return lost_reports, found_reports


def _parse_facts(value: object, rule_id: str, field: str) -> Set[Fact]:
    """Convert JSON [predicate, value] pairs into a set of Fact tuples."""
    if not isinstance(value, list):
        raise ValueError(f"Rule {rule_id}: {field} must be a list")
    facts: Set[Fact] = set()
    for pair in value:
        if (not isinstance(pair, list) or len(pair) != 2
                or not all(isinstance(part, str) for part in pair)):
            raise ValueError(f"Rule {rule_id}: invalid {field} fact: {pair!r}")
        facts.add((pair[0], pair[1]))
    return facts


def load_rules(filepath: str) -> List[Rule]:
    """Load rules.json into Rule objects with tuple facts."""
    with open(filepath, "r", encoding="utf-8-sig") as file:
        payload = json.load(file)
    if not isinstance(payload, list):
        raise ValueError("rules.json must contain a JSON list")

    rules: List[Rule] = []
    for index, item in enumerate(payload, start=1):
        if not isinstance(item, dict):
            raise ValueError(f"Rule entry {index} must be an object")
        for field in ("id", "antecedents", "consequents", "description"):
            if field not in item:
                raise ValueError(f"Rule entry {index} is missing {field!r}")
        rule_id = item["id"]
        if not isinstance(rule_id, str) or not isinstance(item["description"], str):
            raise ValueError(f"Rule entry {index}: id and description must be strings")
        rules.append(Rule(
            id=rule_id,
            antecedents=_parse_facts(item["antecedents"], rule_id, "antecedents"),
            consequents=_parse_facts(item["consequents"], rule_id, "consequents"),
            description=item["description"],
        ))
    return rules


def load_stopwords(filepath: str) -> Set[str]:
    """Load nonempty stopword lines, stripped and lowercased."""
    with open(filepath, "r", encoding="utf-8-sig") as file:
        return {line.strip().lower() for line in file if line.strip()}


def load_ground_truth(filepath: str) -> Dict[str, Tuple[str, Set[str]]]:
    """Map lost_id -> (found_id, set of expected rule IDs).

    Supports expected_rules written as R01;R02, R01|R02, R01,R02,
    or as a JSON array such as ["R01", "R02"]. Blank means no rules.
    """
    ground_truth: Dict[str, Tuple[str, Set[str]]] = {}
    with open(filepath, "r", encoding="utf-8-sig", newline="") as file:
        reader = csv.DictReader(file)
        required = {"lost_id", "found_id", "expected_rules"}
        if reader.fieldnames is None or not required.issubset(reader.fieldnames):
            raise ValueError(f"ground_truth.csv must contain columns: {sorted(required)}")

        for line_number, row in enumerate(reader, start=2):
            if all(not str(value or "").strip() for value in row.values()):
                continue
            if any(not isinstance(row[field], str) for field in required):
                raise ValueError(f"Missing or malformed value on CSV line {line_number}")

            lost_id = row["lost_id"].strip()
            found_id = row["found_id"].strip()
            raw_rules = row["expected_rules"].strip()
            if not lost_id or not found_id:
                raise ValueError(f"Missing lost_id or found_id on CSV line {line_number}")
            if lost_id in ground_truth:
                raise ValueError(f"Duplicate lost_id on CSV line {line_number}: {lost_id}")

            if raw_rules.startswith("["):
                rule_list = json.loads(raw_rules)
                if not isinstance(rule_list, list) or not all(isinstance(r, str) for r in rule_list):
                    raise ValueError(f"Invalid expected_rules on CSV line {line_number}")
                expected_rules = {rule.strip() for rule in rule_list if rule.strip()}
            else:
                expected_rules = {
                    rule.strip() for rule in re.split(r"[;|,]", raw_rules) if rule.strip()
                }
            ground_truth[lost_id] = (found_id, expected_rules)

    return ground_truth
