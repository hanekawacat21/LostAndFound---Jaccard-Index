"""Stage 1: symbolic inference for the DS 170 Lost and Found Matcher.

Implements the three contracts in the project's Module 4 specification:
1. initialize_working_memory
2. forward_chain
3. is_compatible
"""

from typing import List, Set

from .models import Fact, ProcessedReport, Report, Rule
from .preprocessor import preprocess_text


def initialize_working_memory(
    report: Report, stopwords: Set[str], include_zone: bool = True
) -> ProcessedReport:
    """Tokenize a report and initialize its symbolic facts.

    The tokenizer supplies unigrams and contiguous bigrams. Every token becomes
    a ('token', value) fact; a zone fact is optional for ablation experiments.
    """
    tokens = preprocess_text(report.text, stopwords)
    facts: Set[Fact] = {("token", token) for token in tokens}
    if include_zone:
        facts.add(("zone", report.zone))

    return ProcessedReport(report=report, tokens=tokens, facts=facts, trace=[])


def forward_chain(
    proc_report: ProcessedReport, rules: List[Rule]
) -> ProcessedReport:
    """Apply matching symbolic rules until no new facts can be inferred.

    Updates the provided ProcessedReport in place and also returns it. Each
    productive rule firing is recorded once in trace, in firing order.
    """
    fired_rules = set(proc_report.trace)

    while True:
        new_facts_added = False
        for rule in rules:
            if rule.id in fired_rules:
                continue
            if (rule.antecedents.issubset(proc_report.facts)
                    and not rule.consequents.issubset(proc_report.facts)):
                proc_report.facts.update(rule.consequents)
                proc_report.trace.append(rule.id)
                fired_rules.add(rule.id)
                new_facts_added = True

        if not new_facts_added:
            break

    return proc_report


def is_compatible(lost: ProcessedReport, found: ProcessedReport) -> bool:
    """Return False if a specified hard constraint rules out the pair.

    Hard constraints: temporal order, domain clash, disjoint inferred concepts,
    and strictly disjoint inferred colors. Missing concept/color facts do not
    cause pruning (open-world assumption).
    """
    # 1. A found report cannot be dated BEFORE the lost report.
    if found.report.date < lost.report.date:
        return False

    # 2. Known, different item domains cannot match.
    if (lost.report.domain != "unknown"
            and found.report.domain != "unknown"
            and lost.report.domain != found.report.domain):
        return False

    # 3. Incompatible concepts are pruned only when BOTH are known.
    lost_concepts = {v for p, v in lost.facts if p == "concept"}
    found_concepts = {v for p, v in found.facts if p == "concept"}
    if lost_concepts and found_concepts and lost_concepts.isdisjoint(found_concepts):
        return False

    # 4. Incompatible colors are pruned only when BOTH are known.
    lost_colors = {v for p, v in lost.facts if p == "color"}
    found_colors = {v for p, v in found.facts if p == "color"}
    if lost_colors and found_colors and lost_colors.isdisjoint(found_colors):
        return False

    return True

