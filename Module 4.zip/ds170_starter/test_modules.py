"""Smoke test for DS 170 modules 1-3 (not the complete matching pipeline)."""
from pathlib import Path
from src.loader import load_reports, load_rules, load_stopwords, load_ground_truth
from src.preprocessor import preprocess_text

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"

lost_reports, found_reports = load_reports(str(DATA_DIR / "reports.csv"))
rules = load_rules(str(DATA_DIR / "rules.json"))
stopwords = load_stopwords(str(DATA_DIR / "stopwords.txt"))
ground_truth = load_ground_truth(str(DATA_DIR / "ground_truth.csv"))

assert len(lost_reports) == 1
assert len(found_reports) == 1
assert len(rules) == 2
assert ground_truth["L001"] == ("F001", {"R01", "R02"})

tokens = preprocess_text(lost_reports[0].text, stopwords)
assert "hydro_flask" in tokens
assert "my" not in tokens
assert "matte_black" in tokens

print("PASS: Loaded 1 lost report and 1 found report")
print("PASS: Loaded 2 symbolic rules")
print("PASS: Loaded stopwords and ground truth")
print("PASS: Extracted preprocessed tokens:", sorted(tokens))
print("\nModules 1-3 work on the example data.")
print("Matching and ranking require inference.py, ranker.py, and the later modules.")
