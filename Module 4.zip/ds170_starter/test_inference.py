"""Module 4 unit tests; run from project root: python test_inference.py"""
from datetime import date
from pathlib import Path

from src.inference import forward_chain, initialize_working_memory, is_compatible
from src.loader import load_reports, load_rules, load_stopwords
from src.models import ProcessedReport, Report

root = Path(__file__).resolve().parent
lost_reports, found_reports = load_reports(str(root / "data/reports.csv"))
rules = load_rules(str(root / "data/rules.json"))
stopwords = load_stopwords(str(root / "data/stopwords.txt"))

checks = []


def check(name, condition):
    assert condition, f"FAILED: {name}"
    checks.append(name)
    print(f"PASS: {name}")


def make_proc(id, date_str, domain="containers", concepts=(), colors=()):
    report = Report(id=id, domain=domain, date=date.fromisoformat(date_str),
                    zone="test_zone", text="test item")
    facts = {("concept", c) for c in concepts} | {("color", c) for c in colors}
    return ProcessedReport(report=report, facts=facts)


lost = initialize_working_memory(lost_reports[0], stopwords)
found = initialize_working_memory(found_reports[0], stopwords)
check("unigrams and bigrams become token facts", "hydro_flask" in lost.tokens and ("token", "hydro_flask") in lost.facts)
check("zone is added by default", ("zone", "csm_building") in lost.facts)
no_zone = initialize_working_memory(lost_reports[0], stopwords, include_zone=False)
check("zone may be excluded", not any(p == "zone" for p, _ in no_zone.facts))
forward_chain(lost, rules)
forward_chain(found, rules)
check("forward chaining infers subtype, material and concept", {
    ("subtype", "insulated_flask"), ("material", "metal"), ("concept", "DRINK_CONTAINER")
}.issubset(lost.facts))
check("trace records fired rules", lost.trace == ["R01", "R02"])
reversed_order = initialize_working_memory(lost_reports[0], stopwords)
forward_chain(reversed_order, list(reversed(rules)))
check("multi-pass inference works with reversed rule order", reversed_order.trace == ["R01", "R02"])
forward_chain(lost, rules)
check("repeated calls do not duplicate rule trace", lost.trace == ["R01", "R02"])
check("real sample pair passes compatibility checks", is_compatible(lost, found))

base_lost = make_proc("L101", "2026-10-15", concepts={"DRINK_CONTAINER"}, colors={"black"})
base_found = make_proc("F101", "2026-10-16", concepts={"DRINK_CONTAINER"}, colors={"black"})
check("compatible sample", is_compatible(base_lost, base_found))
check("found earlier than lost is pruned", not is_compatible(
    base_lost, make_proc("F102", "2026-10-14", concepts={"DRINK_CONTAINER"}, colors={"black"})))
check("different known domains are pruned", not is_compatible(
    base_lost, make_proc("F103", "2026-10-16", domain="electronics")))
check("different known concepts are pruned", not is_compatible(
    base_lost, make_proc("F104", "2026-10-16", concepts={"ELECTRONICS"})))
check("different known colors are pruned", not is_compatible(
    base_lost, make_proc("F105", "2026-10-16", concepts={"DRINK_CONTAINER"}, colors={"blue"})))
check("missing color does not prune", is_compatible(
    base_lost, make_proc("F106", "2026-10-16", concepts={"DRINK_CONTAINER"})))
check("missing concept does not prune", is_compatible(
    base_lost, make_proc("F107", "2026-10-16", colors={"black"})))
check("unknown domain does not cause domain clash", is_compatible(
    base_lost, make_proc("F108", "2026-10-16", domain="unknown")))
check("same-day found report is allowed", is_compatible(
    base_lost, make_proc("F109", "2026-10-15", concepts={"DRINK_CONTAINER"}, colors={"black"})))

print(f"\n{len(checks)}/{len(checks)} Module 4 checks passed.")

