"""Module 5 tests: standard library only, including real Modules 1-4 integration."""

import unittest
from datetime import date
from pathlib import Path

from src.inference import forward_chain, initialize_working_memory
from src.loader import load_reports, load_rules, load_stopwords
from src.models import ProcessedReport, Report
from src.ranker import get_feature_weight, rank_candidates, weighted_jaccard


def make_processed(
    identifier: str,
    *,
    when: date = date(2026, 10, 16),
    domain: str = "containers",
    facts=(),
) -> ProcessedReport:
    report = Report(
        id=identifier,
        domain=domain,
        date=when,
        zone="csm_building",
        text="test item",
    )
    return ProcessedReport(report=report, facts=set(facts))


class TestFeatureWeights(unittest.TestCase):
    def test_concept_weight(self):
        self.assertEqual(get_feature_weight(("concept", "DRINK_CONTAINER")), 3.0)

    def test_subtype_weight(self):
        self.assertEqual(get_feature_weight(("subtype", "flask")), 2.0)

    def test_material_weight(self):
        self.assertEqual(get_feature_weight(("material", "metal")), 2.0)

    def test_color_weight(self):
        self.assertEqual(get_feature_weight(("color", "black")), 2.0)

    def test_brand_weight(self):
        self.assertEqual(get_feature_weight(("brand", "hydro")), 2.0)

    def test_zone_weight(self):
        self.assertEqual(get_feature_weight(("zone", "csm_building")), 2.0)

    def test_token_weight(self):
        self.assertEqual(get_feature_weight(("token", "hydro_flask")), 1.0)

    def test_uniform_mode_overrides_all_weights(self):
        for pred in ("concept", "subtype", "material", "color", "brand", "zone", "token"):
            self.assertEqual(get_feature_weight((pred, "x"), uniform=True), 1.0)

    def test_undefined_predicate_uses_documented_fallback(self):
        self.assertEqual(get_feature_weight(("custom", "x")), 1.0)


class TestWeightedJaccard(unittest.TestCase):
    def test_both_sets_empty(self):
        self.assertEqual(weighted_jaccard(set(), set()), 0.0)

    def test_one_set_empty(self):
        self.assertEqual(weighted_jaccard({("token", "a")}, set()), 0.0)

    def test_disjoint_sets(self):
        self.assertEqual(weighted_jaccard({("token", "a")}, {("token", "b")}), 0.0)

    def test_identical_nonempty_sets(self):
        facts = {("token", "a"), ("concept", "CONTAINER")}
        self.assertEqual(weighted_jaccard(facts, facts), 1.0)

    def test_expected_weighted_score(self):
        a = {("concept", "CONTAINER"), ("token", "black")}
        b = {("concept", "CONTAINER"), ("token", "blue")}
        self.assertAlmostEqual(weighted_jaccard(a, b), 3.0 / 5.0)

    def test_expected_uniform_score(self):
        a = {("concept", "CONTAINER"), ("token", "black")}
        b = {("concept", "CONTAINER"), ("token", "blue")}
        self.assertAlmostEqual(weighted_jaccard(a, b, uniform=True), 1.0 / 3.0)

    def test_zone_weight_included(self):
        a = {("zone", "csm_building"), ("token", "a")}
        b = {("zone", "csm_building"), ("token", "b")}
        self.assertAlmostEqual(weighted_jaccard(a, b), 0.5)

    def test_symmetric_score(self):
        a = {("material", "metal"), ("token", "a")}
        b = {("material", "metal"), ("token", "b")}
        self.assertEqual(weighted_jaccard(a, b), weighted_jaccard(b, a))

    def test_no_input_mutation(self):
        a = {("token", "a")}
        b = {("token", "b")}
        before_a, before_b = a.copy(), b.copy()
        weighted_jaccard(a, b)
        self.assertEqual(a, before_a)
        self.assertEqual(b, before_b)


class TestRankCandidates(unittest.TestCase):
    def setUp(self):
        self.lost = make_processed(
            "L001", when=date(2026, 10, 15),
            facts={("concept", "CONTAINER"), ("token", "flask"), ("zone", "csm")},
        )

    def test_empty_pool(self):
        self.assertEqual(rank_candidates(self.lost, []), [])

    def test_identical_candidate(self):
        candidate = make_processed("F001", facts=self.lost.facts)
        self.assertEqual(rank_candidates(self.lost, [candidate]), [("F001", 1.0)])

    def test_highest_score_first(self):
        low = make_processed("F010", facts={("zone", "csm")})
        high = make_processed("F002", facts=set(self.lost.facts))
        ranked = rank_candidates(self.lost, [low, high])
        self.assertEqual([found_id for found_id, _ in ranked], ["F002", "F010"])

    def test_ties_break_by_ascending_found_id(self):
        a = make_processed("F020", facts={("token", "flask")})
        b = make_processed("F003", facts={("token", "flask")})
        c = make_processed("F010", facts={("token", "flask")})
        ranked = rank_candidates(self.lost, [a, b, c])
        self.assertEqual([found_id for found_id, _ in ranked], ["F003", "F010", "F020"])

    def test_temporal_pruning(self):
        older = make_processed("F001", when=date(2026, 10, 14), facts=self.lost.facts)
        self.assertEqual(rank_candidates(self.lost, [older]), [])

    def test_domain_pruning(self):
        other = make_processed("F001", domain="electronics", facts=self.lost.facts)
        self.assertEqual(rank_candidates(self.lost, [other]), [])

    def test_disjoint_concept_pruning(self):
        other = make_processed("F001", facts={("concept", "ELECTRONICS")})
        self.assertEqual(rank_candidates(self.lost, [other]), [])

    def test_disjoint_color_pruning(self):
        lost = make_processed("L001", when=date(2026, 10, 15), facts={("color", "black")})
        other = make_processed("F001", facts={("color", "blue")})
        self.assertEqual(rank_candidates(lost, [other]), [])

    def test_missing_concept_does_not_prune(self):
        other = make_processed("F001", facts={("token", "other")})
        self.assertEqual(len(rank_candidates(self.lost, [other])), 1)

    def test_missing_color_does_not_prune(self):
        lost = make_processed("L001", when=date(2026, 10, 15), facts={("color", "black")})
        other = make_processed("F001", facts={("token", "other")})
        self.assertEqual(len(rank_candidates(lost, [other])), 1)

    def test_unknown_domain_does_not_prune(self):
        other = make_processed("F001", domain="unknown", facts=self.lost.facts)
        self.assertEqual(len(rank_candidates(self.lost, [other])), 1)

    def test_disable_pruning_preserves_incompatible_pair(self):
        older = make_processed("F001", when=date(2026, 10, 14), facts=self.lost.facts)
        self.assertEqual(rank_candidates(self.lost, [older], use_pruning=False), [("F001", 1.0)])

    def test_uniform_weights_change_score(self):
        lost = make_processed("L001", when=date(2026, 10, 15), facts={("concept", "CONTAINER"), ("token", "black")})
        found = make_processed("F001", facts={("concept", "CONTAINER"), ("token", "blue")})
        weighted_score = rank_candidates(lost, [found], uniform_weights=False)[0][1]
        uniform_score = rank_candidates(lost, [found], uniform_weights=True)[0][1]
        self.assertAlmostEqual(weighted_score, 0.6)
        self.assertAlmostEqual(uniform_score, 1.0 / 3.0)

    def test_zero_score_survivor_is_kept(self):
        other = make_processed("F001", facts={("token", "unrelated")})
        self.assertEqual(rank_candidates(self.lost, [other]), [("F001", 0.0)])

    def test_all_pruned_returns_empty(self):
        a = make_processed("F001", domain="electronics", facts=self.lost.facts)
        b = make_processed("F002", when=date(2026, 10, 14), facts=self.lost.facts)
        self.assertEqual(rank_candidates(self.lost, [a, b]), [])

    def test_no_input_mutation(self):
        candidate = make_processed("F001", facts={("token", "flask")})
        self.lost.trace.append("R01")
        candidate.trace.append("R02")
        lost_facts, candidate_facts = self.lost.facts.copy(), candidate.facts.copy()
        lost_trace, candidate_trace = self.lost.trace.copy(), candidate.trace.copy()
        pool = [candidate]
        rank_candidates(self.lost, pool)
        self.assertEqual(self.lost.facts, lost_facts)
        self.assertEqual(candidate.facts, candidate_facts)
        self.assertEqual(self.lost.trace, lost_trace)
        self.assertEqual(candidate.trace, candidate_trace)
        self.assertEqual(pool, [candidate])

    def test_repeatable_results(self):
        pool = [make_processed("F002", facts={("token", "flask")}), make_processed("F001", facts={("token", "flask")})]
        self.assertEqual(rank_candidates(self.lost, pool), rank_candidates(self.lost, pool))

    def test_integration_with_real_modules_1_to_4(self):
        data = Path(__file__).resolve().parent / "data"
        lost_reports, found_reports = load_reports(str(data / "reports.csv"))
        rules = load_rules(str(data / "rules.json"))
        stopwords = load_stopwords(str(data / "stopwords.txt"))
        lost = forward_chain(initialize_working_memory(lost_reports[0], stopwords), rules)
        found = forward_chain(initialize_working_memory(found_reports[0], stopwords), rules)
        rankings = rank_candidates(lost, [found])
        self.assertEqual(rankings[0][0], "F001")
        self.assertGreater(rankings[0][1], 0.0)
        self.assertLessEqual(rankings[0][1], 1.0)
        self.assertEqual(lost.trace, ["R01", "R02"])
        self.assertEqual(found.trace, ["R01", "R02"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
