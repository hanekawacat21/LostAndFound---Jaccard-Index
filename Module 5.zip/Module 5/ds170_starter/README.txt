DS 170 — Symbolic-Lexical Campus Lost and Found Matcher
Modules 1–5 (Google Colab starter)

Python 3: No third-party packages required for running the module tests and demo.

RECOMMENDED: Download and open DS170_Module5_Google_Colab.ipynb separately
in Google Colab, then upload this ZIP when prompted.

DIRECT COLAB METHOD:
1. Upload the ZIP to Colab.
2. Extract into /content. The top-level folder is ds170_starter.
3. In a code cell: %cd /content/ds170_starter
4. Run the following commands in separate Colab code cells:
      !python test_modules.py
      !python test_inference.py
      !python test_ranker.py
      !python demo_ranker.py

FILES:
src/models.py         Data contracts (Module 1)
src/loader.py         CSV/JSON ingestion (Module 2)
src/preprocessor.py   Unigrams and bigrams (Module 3)
src/inference.py      Forward chaining and hard pruning (Module 4)
src/ranker.py         Weighted Jaccard and ranking (Module 5)
test_ranker.py        36 Module 5 checks, including Modules 1–4 integration
demo_ranker.py        Executable end-to-end Modules 1–5 demo

data/                  Illustrative reports, rules, stopwords and ground truth

IMPORTANT NOTES:
- The datasets in this ZIP are only a tiny demonstrative sample, not a full
  training/test corpus or credible project-performance evaluation.
- Evaluation metrics and a five-mode ablation study belong to Module 6.
- main.py (complete project entry point) belongs to Module 7.
- The PDF did not specify a weight for unknown predicate types; ranker.py
  conservatively defaults them to 1.0.
- Even zero-score surviving candidates are returned by Module 5; the PDF's
  Module 6 requires a positive score for Top-1/Top-3 retrieval hits.
