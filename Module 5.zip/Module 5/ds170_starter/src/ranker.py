"""Stage 2: feature-weighted Jaccard ranking for lost-and-found reports.

Module 5 from the DS 170 Symbolic-Lexical Campus Lost and Found Matcher
specification. This module accepts ProcessedReport objects from Module 4.
"""

from typing import List, Set, Tuple

from .inference import is_compatible
from .models import Fact, ProcessedReport


def get_feature_weight(fact: Fact, uniform: bool = False) -> float:
    """Return the specification's feature weight for a (predicate, value) fact.

    concept -> 3.0
    subtype/material/color/brand/zone -> 2.0
    token -> 1.0
    uniform=True -> 1.0 for every fact

    The PDF does not define a weight for other predicate names; they are
    conservatively treated like tokens (weight 1.0).
    """
    if uniform:
        return 1.0

    predicate = fact[0]
    if predicate == "concept":
        return 3.0
    if predicate in {"subtype", "material", "color", "brand", "zone"}:
        return 2.0
    return 1.0


def weighted_jaccard(
    facts_a: Set[Fact],
    facts_b: Set[Fact],
    uniform: bool = False,
) -> float:
    """Compute sum(weights in intersection) / sum(weights in union).

    Returns 0.0 for two empty sets, as explicitly required by the PDF.
    """
    union = facts_a | facts_b
    if not union:
        return 0.0

    intersection = facts_a & facts_b
    numerator = sum(get_feature_weight(fact, uniform) for fact in intersection)
    denominator = sum(get_feature_weight(fact, uniform) for fact in union)
    return numerator / denominator


def rank_candidates(
    lost: ProcessedReport,
    found_pool: List[ProcessedReport],
    use_pruning: bool = True,
    uniform_weights: bool = False,
) -> List[Tuple[str, float]]:
    """Score candidates; return (found_id, score) sorted by score then ID.

    With pruning on, incompatible candidates are omitted entirely.
    Score-zero candidates are retained, since the PDF specifies sorting all
    surviving candidates; Module 6 decides whether a result counts as a hit.
    """
    rankings: List[Tuple[str, float]] = []

    for found in found_pool:
        if use_pruning and not is_compatible(lost, found):
            continue
        score = weighted_jaccard(lost.facts, found.facts, uniform=uniform_weights)
        rankings.append((found.report.id, score))

    return sorted(rankings, key=lambda candidate: (-candidate[1], candidate[0]))
