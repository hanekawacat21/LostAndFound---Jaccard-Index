"""Standalone Module 5 demo: run with python demo_ranker.py from project root."""
from datetime import date
from pathlib import Path

from src.inference import forward_chain, initialize_working_memory
from src.loader import load_reports, load_rules, load_stopwords
from src.models import Report
from src.ranker import rank_candidates

DATA = Path(__file__).resolve().parent / "data"
lost_reports, found_reports = load_reports(str(DATA / "reports.csv"))
rules = load_rules(str(DATA / "rules.json"))
stopwords = load_stopwords(str(DATA / "stopwords.txt"))


def process(report):
    return forward_chain(initialize_working_memory(report, stopwords), rules)


lost = process(lost_reports[0])
found_pool = [
    process(found_reports[0]),
    process(Report("F002", "containers", date(2026, 10, 17), "csm_building", "Found a blue lunch box")),
    process(Report("F003", "electronics", date(2026, 10, 16), "csm_building", "Found a matte black hydro flask")),
    process(Report("F004", "containers", date(2026, 10, 14), "csm_building", "Found a matte black hydro flask")),
    process(Report("F005", "containers", date(2026, 10, 17), "engineering_building", "Found a black flask")),
]

print(f"Lost report: {lost.report.id} - {lost.report.text}")
print(f"Found candidates supplied: {len(found_pool)}")

print("\nFull system ranking (pruning + weighted Jaccard):")
rankings = rank_candidates(lost, found_pool)
for found_id, score in rankings:
    print(f"  {found_id}: {score:.4f}")

included = {id for id, _ in rankings}
print("Pruned report IDs:", ", ".join(sorted(x.report.id for x in found_pool if x.report.id not in included)))

print("\nAblation preview (no pruning + uniform weights):")
for found_id, score in rank_candidates(lost, found_pool, use_pruning=False, uniform_weights=True):
    print(f"  {found_id}: {score:.4f}")

print("\nReminder: Module 5 ranks candidates. It does not compute Top-K or MRR yet.")
