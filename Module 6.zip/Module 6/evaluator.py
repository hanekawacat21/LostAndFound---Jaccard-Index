"""Module 6: evaluation and five-mode ablation study for DS 170.

Implements the metrics and modes in the Symbolic-Lexical Campus Lost and
Found Matcher project specification. Uses only Python's standard library.

Design choices where the PDF permits alternatives:
* Exact Lookup (Mode 1): literal equality of preprocessed token sets.
* Trace Accuracy: exact SET equality for fired vs. expected rule IDs.
* Every mode uses deterministic score-descending, found-ID-ascending sorting.
"""

from typing import Dict, List, Set, Tuple

from .inference import forward_chain, initialize_working_memory
from .models import ProcessedReport, Report, Rule
from .preprocessor import preprocess_text
from .ranker import rank_candidates, weighted_jaccard

Ranking = List[Tuple[str, float]]
GroundTruth = Dict[str, Tuple[str, Set[str]]]

MODE_NAMES = (
    "Mode 1 - Exact Lookup",
    "Mode 2 - Raw Jaccard",
    "Mode 3 - Pruning + Raw Jaccard",
    "Mode 4 - Pruning + Inference + Uniform Weights",
    "Mode 5 - Full System",
)


def compute_retrieval_metrics(
    rankings: Dict[str, Ranking], ground_truth: GroundTruth
) -> Dict[str, float]:
    """Evaluate Top-1, Top-3 and MRR over ALL labeled lost report IDs.

    A true found ID counts as a hit only if its similarity score is > 0.
    A missing query, missing answer or score-zero answer contributes zero.
    Returns zero metrics when no ground truth queries are supplied.
    """
    if not ground_truth:
        return {"Top-1 Accuracy": 0.0, "Top-3 Accuracy": 0.0, "MRR": 0.0}

    top1 = 0
    top3 = 0
    reciprocal_rank_sum = 0.0

    for lost_id, (true_found_id, _) in ground_truth.items():
        candidate_list = rankings.get(lost_id, [])
        for rank, (found_id, score) in enumerate(candidate_list, start=1):
            if found_id == true_found_id and score > 0.0:
                if rank == 1:
                    top1 += 1
                if rank <= 3:
                    top3 += 1
                reciprocal_rank_sum += 1.0 / rank
                break

    n = len(ground_truth)
    return {
        "Top-1 Accuracy": top1 / n,
        "Top-3 Accuracy": top3 / n,
        "MRR": reciprocal_rank_sum / n,
    }


def compute_trace_accuracy(
    processed_reports: Dict[str, ProcessedReport], ground_truth: GroundTruth
) -> float:
    """Fraction of labeled queries with EXACTLY the expected fired rule IDs.

    We compare sets, not firing order. Missing processed report IDs count as
    incorrect. When both rule sets are empty, this correctly counts as exact.
    """
    if not ground_truth:
        return 0.0

    exact_matches = 0
    for lost_id, (_, expected_rules) in ground_truth.items():
        processed = processed_reports.get(lost_id)
        if processed is not None and set(processed.trace) == expected_rules:
            exact_matches += 1

    return exact_matches / len(ground_truth)


def _passes_basic_constraints(lost: Report, found: Report) -> bool:
    """Mode 3 ONLY: prune on date and domain (NOT concepts or colors)."""
    if found.date < lost.date:
        return False
    if (
        lost.domain != "unknown"
        and found.domain != "unknown"
        and lost.domain != found.domain
    ):
        return False
    return True


def _sorted_candidates(candidates: Ranking) -> Ranking:
    return sorted(candidates, key=lambda item: (-item[1], item[0]))


def _check_ids(
    lost_reports: List[Report], found_reports: List[Report], ground_truth: GroundTruth
) -> None:
    """Reject a silently invalid benchmark; unlabeled lost reports are allowed."""
    lost_ids = [r.id for r in lost_reports]
    found_ids = [r.id for r in found_reports]
    if len(lost_ids) != len(set(lost_ids)) or len(found_ids) != len(set(found_ids)):
        raise ValueError("Report IDs must be unique within lost and found collections")
    unknown_lost = set(ground_truth) - set(lost_ids)
    if unknown_lost:
        raise ValueError(f"Ground truth refers to missing lost IDs: {sorted(unknown_lost)}")
    unknown_found = {target for target, _ in ground_truth.values()} - set(found_ids)
    if unknown_found:
        raise ValueError(f"Ground truth refers to missing found IDs: {sorted(unknown_found)}")


def run_ablation_study(
    lost_reports: List[Report],
    found_reports: List[Report],
    rules: List[Rule],
    stopwords: Set[str],
    ground_truth: GroundTruth,
) -> Dict[str, Dict[str, float]]:
    """Run the five prescribed modes independently and return their metrics.

    Mode 1: Exact preprocessed TOKEN-SET equality, no inference/pruning.
    Mode 2: Raw-token unweighted Jaccard, no inference/pruning.
    Mode 3: Mode 2 with ONLY temporal/domain pruning.
    Mode 4: Forward chaining + all 4 constraints + uniform fact weights.
    Mode 5: Forward chaining + all 4 constraints + weighted fact Jaccard.

    All ProcessedReport objects are freshly initialized for each mode, so
    forward chaining never mutates caller-owned objects or another mode.
    Queries without a ground-truth label are not included in evaluation.
    """
    _check_ids(lost_reports, found_reports, ground_truth)
    report_by_id = {report.id: report for report in lost_reports}
    query_reports = [report_by_id[lost_id] for lost_id in ground_truth]

    result: Dict[str, Dict[str, float]] = {}

    for mode_number, mode_name in enumerate(MODE_NAMES, start=1):
        rankings: Dict[str, Ranking] = {}
        processed_queries: Dict[str, ProcessedReport] = {}

        if mode_number <= 3:
            # Token-only ablation: do not add zone/concept/subtype facts.
            tokenized_lost = {
                report.id: preprocess_text(report.text, stopwords)
                for report in query_reports
            }
            tokenized_found = {
                report.id: preprocess_text(report.text, stopwords)
                for report in found_reports
            }

            for lost in query_reports:
                lost_tokens = tokenized_lost[lost.id]
                candidates: Ranking = []
                for found in found_reports:
                    if mode_number == 3 and not _passes_basic_constraints(lost, found):
                        continue

                    found_tokens = tokenized_found[found.id]
                    if mode_number == 1:
                        score = 1.0 if lost_tokens == found_tokens else 0.0
                    else:
                        a = {("token", token) for token in lost_tokens}
                        b = {("token", token) for token in found_tokens}
                        score = weighted_jaccard(a, b, uniform=True)
                    candidates.append((found.id, score))

                rankings[lost.id] = _sorted_candidates(candidates)
                processed_queries[lost.id] = ProcessedReport(
                    report=lost,
                    tokens=set(lost_tokens),
                    facts={("token", token) for token in lost_tokens},
                    trace=[],
                )

        else:
            # Fresh, independent objects for each inference-enabled mode.
            found_pool = [
                forward_chain(initialize_working_memory(report, stopwords), rules)
                for report in found_reports
            ]
            for lost in query_reports:
                proc_lost = forward_chain(
                    initialize_working_memory(lost, stopwords), rules
                )
                processed_queries[lost.id] = proc_lost
                rankings[lost.id] = rank_candidates(
                    proc_lost,
                    found_pool,
                    use_pruning=True,
                    uniform_weights=(mode_number == 4),
                )

        metrics = compute_retrieval_metrics(rankings, ground_truth)
        metrics["Trace Accuracy"] = compute_trace_accuracy(
            processed_queries, ground_truth
        )
        result[mode_name] = metrics

    return result
